Introduction to Optimization with MATLAB(R) Products - Webinar - 26 October 2006

The files contained in this zip file are from the October 26, 2006 webinar.
It is recommended you view the webinar prior to running these files.  To
view the webinar, go to http://www.mathworks.com/webinars and look for the
'Introduction to Optimization with MATLAB(R) Products' webinar.  A copy of the
presentation slides are included in this download.

Please be aware that you will need MATLAB(R), Optimization Toolbox, Genetic
Algorithm and Direct Search Toolbox, Simulink, and SimMechanics to run this
code.  Virtual Reality Toolbox is needed (optional) to view the animation of
the Simulink model.  To request a trial of these products please visit:

http://www.mathworks.com/products/optimization/tryit.html
-or-
http://www.mathworks.com/products/gads/tryit.html.

You should step through walkthrough.m in cell execution mode so that you can
see the results in a sequence shown in the webinar on October 26.  To enable
cell mode, first open the M-file by typing "edit walkthrough" at the MATLAB 
command prompt.  Once the editor opens, go to the "Cell" menu and select
"Enable Cell Mode".  Once cell mode is enabled, you can right-click within 
each cell (cells begin with %%) and select "Evaluate Current Cell".

This script is commented such that it produces a detailed report if you 
publish it (original in downloaded HTML folder).  This report includes 
background information, a description of what the code is doing, Code 
samples, figures, and an analysis of the results.  To publish the M-file, 
go to the "File" menu within the editor and "Publish To" your desired file 
format.

---------------------------------------------------------------------------
Contained in this download are:

Info:       
   README.txt                            this document
   Into to Optimization Webinar.pdf      presentation slides

Webinar Archive:
    http://www.mathworks.com/company/events/archived_webinars.html

M-Files:
   importfile.m             Function to import idealProfile.xls
   updatePlot.m             Custom plot for showing profiles during solution       
   verifyInstalled.m        Function to check for required products
   walkthrough.m            CELL MODE WALK THROUGH OF DEMO
   wbObjFun.m               Objective function definition
   wbOptimSetUp.m           Sets up the optimization problem (A,lb,x,etc...)
   wbPlotFun.m              Custom plot function

MAT-Files:
   idealSolution.mat        Ideal profile definition      
   optimtoolProblem.mat     Optimtool problem definition structure
   wbPSOpt.mat              Contains x0c and psearchtool option structure

MDL-Files:
   DoubleWishbone.mdl       Simulink/SimMechanics model
   DoubleWishboneVR.mdl     Simulink/SimMechanics model with Virtual Reality

WRL-Files: (Virtual Reality Files for showing Animation)
   cones_potholes.wrl
   racecar_body_nolinks.wrl
   road_potholes.wrl 
   vrscene_racecar.wrl         
   vrscene_racecar_anim_1.wrl

PNG-Files:
   schematic.png            Drawing of double wishbone geometry

Excel (XLS) FIles:
    idealProfile.xls        Ideal profile contained in Excel
       
HTML Folder:
   MATLAB published version of walkthrough.m.  To view, open walkthrough.html
   in a web browser.

TEXTURE Folder:
   Folder containing image files for the Simulink model.

---------------------------------------------------------------------------
Questions/Comments:
stuart.kozola@mathworks.com