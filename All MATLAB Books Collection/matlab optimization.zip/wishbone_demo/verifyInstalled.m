function verifyInstalled
%VERIFYINSTALLED Checks for installed products
% VERIFYINSTALLED checks to ensure required products are installed.
% Required products incldue:
%   MATLAB
%   Simulink
%   Optimization Toolbox
%   Genetic Algorithm and Direct Search Toolbox
%   SimMechanics
%   Virtual Reality Toolbox

% Product List
product = {'MATLAB'
           'optimization_toolbox'
           'gads_toolbox'
           'Simulink'
           'SimMechanics'};

% Check for license
for i = 1:length(product)
    if ~license('test',product{i})
        error('You need to have %s installed to run this Demo',product{i})
    end
end