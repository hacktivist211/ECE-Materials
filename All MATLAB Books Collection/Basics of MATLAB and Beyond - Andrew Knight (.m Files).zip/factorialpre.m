y = zeros(1,500);
for number = 1:500
  y(number) = prod(1:number);
end