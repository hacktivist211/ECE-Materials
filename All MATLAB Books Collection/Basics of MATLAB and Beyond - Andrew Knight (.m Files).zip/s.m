function s

% Bring the current figure into the foreground. 

% A. Knight April 1999

shg
