newAxesHandle = copyobj(gca);
figure(2)
set(newAxesHandle,'Parent',2)
