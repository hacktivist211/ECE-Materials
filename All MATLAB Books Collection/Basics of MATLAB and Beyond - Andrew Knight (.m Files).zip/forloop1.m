N = length(a);b = zeros(1,N - 1);for i=1:N-1  b(i) = a(i) + a(i + 1);end
