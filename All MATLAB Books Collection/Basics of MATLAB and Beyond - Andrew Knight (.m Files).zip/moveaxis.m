set(gca,'ButtonDownFcn','selectmoveresize');
set(gcf,'WindowButtonDownFcn','selectmoveresize'); %optional
